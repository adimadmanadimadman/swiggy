# chwiggy
Swiggy clone using ReactJS, Node, Express and Mongo DB.

Run server.js to run the backend server
Run initializeDB to setup dummy data once server and mongoDB are running
You only need to run initializeDB once