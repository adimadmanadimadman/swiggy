import productSagas from './product/sagas'

export default [
  productSagas
]
